import os
import json
import wave
import time
import logging
import struct
import io
import subprocess
import asyncio
import audioop
import math
import glob
from datetime import datetime
from flask import Flask, render_template_string, request, jsonify
from flask_sock import Sock
from groq import Groq
import edge_tts

# --- DEPENDENCIAS ---
try:
    import opuslib
except ImportError:
    print("❌ 'opuslib' no instalado. Audio comprimido desactivado.")
    opuslib = None

# --- CONFIGURACIÓN ---
CONFIG_FILE = 'config.json'
CHATS_DIR = 'chats' 
if not os.path.exists(CHATS_DIR): os.makedirs(CHATS_DIR)

# --- ROLES ---
PROMPT_PRESETS = {
    "default": { "label": "🤖 Asistente", "icon": "robot", "prompt": "Eres Xiaozhi, un asistente útil y amable." },
    "historia": { "label": "🏺 Historiador", "icon": "book", "prompt": "Eres un experto historiador. Narra hechos históricos con pasión." },
    "medico": { "label": "🩺 Médico", "icon": "heart", "prompt": "Eres un médico empático. Da consejos generales de salud." },
    "sysadmin": { "label": "💻 SysAdmin", "icon": "terminal", "prompt": "Eres experto en Linux, redes y DevOps." },
    "dev": { "label": "👨‍💻 Programador", "icon": "code", "prompt": "Eres Senior Developer. Escribe código limpio y optimizado." },
    "abogado": { "label": "⚖️ Abogado", "icon": "scale", "prompt": "Eres abogado. Asesora con terminología legal clara." },
    "chef": { "label": "👨‍🍳 Chef", "icon": "chef", "prompt": "Eres un Chef experto. Da recetas y trucos de cocina." }
}

DEFAULT_CONFIG = {
    "groq_api_key": "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",
    "system_prompt": PROMPT_PRESETS["default"]["prompt"],
    "current_role": "default",
    "model": "llama-3.3-70b-versatile",
    "voice": "es-ES-AlvaroNeural",
    "tts_rate_val": 0, "tts_pitch_val": 0,
    "mic_gain": 1.0, "silence_threshold": 500, "silence_duration": 2.5,
    "llm_temperature": 0.7, "context_memory": 6, "max_tokens": 1024
}

GROQ_MODELS = ["openai/gpt-oss-120b", "llama-3.3-70b-versatile", "llama-3.1-8b-instant", "gemma2-9b-it"]

VOICE_OPTIONS = {
    "es-ES-AlvaroNeural": "🇪🇸 Álvaro (Hombre)", "es-ES-ElviraNeural": "🇪🇸 Elvira (Mujer)",
    "es-MX-DaliaNeural": "🇲🇽 Dalia (Mujer MX)", "en-US-ChristopherNeural": "🇺🇸 Christopher (EN)"
}

INPUT_RATE = 16000; INPUT_CHANNELS = 1; OUTPUT_RATE = 16000; OUTPUT_CHANNELS = 1; FRAME_SIZE = 960 

# --- ESTADO GLOBAL ---
current_active_chat_id = None 
robot_ws_connection = None
robot_status = { "battery": 0, "wifi": 0, "vol": 50, "screen": "neutral" }

app = Flask(__name__)
sock = Sock(app)
log = logging.getLogger('werkzeug'); log.setLevel(logging.ERROR)

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f: return {**DEFAULT_CONFIG, **json.load(f)}
        except: pass
    return DEFAULT_CONFIG.copy()

def save_config(new_config):
    with open(CONFIG_FILE, 'w') as f: json.dump(new_config, f, indent=4)

config = load_config()

# --- GESTIÓN DE CHATS ---
def get_chat_filename(chat_id): return os.path.join(CHATS_DIR, f"{chat_id}.json")

def create_new_chat():
    chat_id = datetime.now().strftime("chat_%Y%m%d_%H%M%S")
    role_key = config.get('current_role', 'default')
    preset = PROMPT_PRESETS.get(role_key, PROMPT_PRESETS['default'])
    icon = preset['icon']
    data = { "id": chat_id, "title": "Nuevo Chat", "icon": icon, "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "messages": [] }
    with open(get_chat_filename(chat_id), 'w', encoding='utf-8') as f: json.dump(data, f, indent=4)
    return chat_id

def delete_chat_file(chat_id):
    try: os.remove(get_chat_filename(chat_id)); return True
    except: return False

def save_message_to_chat(chat_id, role, content):
    filename = get_chat_filename(chat_id)
    if not os.path.exists(filename): return
    with open(filename, 'r+', encoding='utf-8') as f:
        data = json.load(f)
        if len(data['messages']) == 0 and role == 'user': data['title'] = content[:30] + "..."
        data['messages'].append({"role": role, "content": content, "timestamp": datetime.now().strftime("%H:%M")})
        f.seek(0); json.dump(data, f, indent=4, ensure_ascii=False); f.truncate()

def load_chat_content(chat_id):
    try:
        with open(get_chat_filename(chat_id), 'r', encoding='utf-8') as f: return json.load(f)
    except: return None

def list_all_chats():
    files = glob.glob(os.path.join(CHATS_DIR, "chat_*.json"))
    chats = []
    for f in files:
        try:
            with open(f, 'r', encoding='utf-8') as jf:
                d = json.load(jf)
                chats.append({"id": d['id'], "title": d.get('title','Chat'), "icon": d.get('icon','robot'), "date": d['created_at']})
        except: pass
    return sorted(chats, key=lambda x: x['date'], reverse=True)

# --- IA CORE (PROTEGIDO) ---
def process_full_interaction(pcm_data, ws):
    global current_active_chat_id, robot_ws_connection
    
    # DETECTAR SI LA CONEXIÓN ES EL ROBOT
    is_robot = (ws == robot_ws_connection)

    if not current_active_chat_id:
        current_active_chat_id = create_new_chat()
        # Solo enviamos cambio de chat a la web, NO al robot
        if not is_robot: 
            try: ws.send(json.dumps({"type": "switch_chat", "chat_id": current_active_chat_id}))
            except: pass

    if config.get('mic_gain', 1.0) != 1.0:
        try: pcm_data = audioop.mul(pcm_data, 2, config['mic_gain'])
        except: pass

    if len(pcm_data) < 4000: return

    try:
        client = Groq(api_key=config['groq_api_key'])
        wav_buffer = io.BytesIO()
        with wave.open(wav_buffer, 'wb') as wf:
            wf.setnchannels(INPUT_CHANNELS); wf.setsampwidth(2); wf.setframerate(INPUT_RATE)
            wf.writeframes(pcm_data)
        wav_buffer.seek(0)
        
        # UI Update solo si NO es robot (El robot se cuelga con estos mensajes)
        if not is_robot:
            try: ws.send(json.dumps({"type": "typing", "text": "👂 Escuchando..."}))
            except: pass
        
        # Comando hardware SEGURO
        send_robot_command("screen", "listening")

        transcription = client.audio.transcriptions.create(
            file=("input.wav", wav_buffer.read()), model="whisper-large-v3-turbo", language="es"
        )
        user_text = transcription.text
        print(f"User: {user_text}")
        
        save_message_to_chat(current_active_chat_id, "user", user_text)
        
        # Update Web
        if not is_robot:
            try: ws.send(json.dumps({"type": "new_msg", "chat_id": current_active_chat_id}))
            except: pass
            
    except: return

    try:
        send_robot_command("screen", "thinking")
        chat_data = load_chat_content(current_active_chat_id)
        msgs = [{"role": "system", "content": config['system_prompt']}]
        limit = config.get('context_memory', 6)
        hist = chat_data['messages'][-limit:] if chat_data else []
        for h in hist:
            role = "assistant" if h['role'] == "ai" else h['role']
            msgs.append({"role": role, "content": h['content']})
        if limit == 0: msgs.append({"role": "user", "content": user_text})

        completion = client.chat.completions.create(
            model=config['model'], 
            messages=msgs, 
            temperature=config['llm_temperature'],
            max_tokens=config.get('max_tokens', 1024)
        )
        ai_response = completion.choices[0].message.content
        save_message_to_chat(current_active_chat_id, "ai", ai_response)
        
        if not is_robot:
            try: ws.send(json.dumps({"type": "new_msg", "chat_id": current_active_chat_id}))
            except: pass
            
    except: return

    try:
        send_robot_command("screen", "speaking")
        
        if not is_robot:
            ws.send(json.dumps({"type": "typing", "text": "🔊 Generando..."}))
            
        pcm_audio = asyncio.run(generate_tts_pcm(ai_response))
        
        if pcm_audio: 
            # Pequeña pausa para que el robot cambie de RX a TX
            time.sleep(0.1)
            send_audio_stream(ws, pcm_audio)
    except: pass
    
    if not is_robot:
        ws.send(json.dumps({"type": "typing", "text": ""}))
        
    send_robot_command("screen", "neutral")

async def generate_tts_pcm(text):
    rate_val = config.get('tts_rate_val', 0)
    pitch_val = config.get('tts_pitch_val', 0)
    rate_str = f"{'+' if rate_val >= 0 else ''}{rate_val}%"
    pitch_str = f"{'+' if pitch_val >= 0 else ''}{pitch_val}Hz"

    communicate = edge_tts.Communicate(text, config['voice'], rate=rate_str, pitch=pitch_str)
    mp3_data = b""
    async for chunk in communicate.stream():
        if chunk["type"] == "audio": mp3_data += chunk["data"]
    try:
        cmd = ["ffmpeg", "-y", "-i", "pipe:0", "-f", "s16le", "-acodec", "pcm_s16le", "-ar", str(OUTPUT_RATE), "-ac", "1", "pipe:1"]
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        out, _ = proc.communicate(input=mp3_data)
        return out
    except: return b""

def send_audio_stream(ws, pcm_audio):
    # MENSAJE CRÍTICO: El robot espera esto para preparar el speaker
    ws.send(json.dumps({"type": "tts", "state": "start"}))
    if opuslib:
        encoder = opuslib.Encoder(OUTPUT_RATE, OUTPUT_CHANNELS, opuslib.APPLICATION_VOIP)
        FRAME_SAMPLES = 960; CHUNK_BYTES = FRAME_SAMPLES * 2 
        for i in range(0, len(pcm_audio), CHUNK_BYTES):
            chunk = pcm_audio[i:i+CHUNK_BYTES]
            if len(chunk) < CHUNK_BYTES: chunk += b'\x00' * (CHUNK_BYTES - len(chunk))
            try:
                encoded = encoder.encode(chunk, FRAME_SAMPLES)
                # Enviar BYTES puros (El robot sabe que bytes = audio)
                ws.send(encoded)
                time.sleep(0.058) 
            except: pass
    ws.send(json.dumps({"type": "tts", "state": "stop"}))

def get_volume(pcm_chunk):
    try:
        shorts = struct.unpack(f"{len(pcm_chunk)//2}h", pcm_chunk)
        return int(math.sqrt(sum(n*n for n in shorts)/len(shorts)))
    except: return 0

def send_robot_command(cmd_type, value):
    global robot_ws_connection
    if robot_ws_connection:
        try: 
            # JSON MÍNIMO para no saturar memoria del ESP32
            robot_ws_connection.send(json.dumps({"type": "cmd", "c": cmd_type, "v": value}))
        except: pass

# --- UI TEMPLATE V17 ---
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xiaozhi AI V17</title>
    <style>
        :root { --bg-dark: #202123; --bg-main: #343541; --text-main: #ececf1; --accent: #10a37f; --accent-hover: #0e8c6d; --border: #4d4d4f; }
        body { margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg-main); color: var(--text-main); display: flex; height: 100vh; overflow: hidden; }
        .icon-svg { width: 20px; height: 20px; fill: currentColor; vertical-align: middle; }
        .icon-sm { width: 16px; height: 16px; }

        .sidebar { width: 280px; background: var(--bg-dark); display: flex; flex-direction: column; border-right: 1px solid var(--border); }
        .sidebar-header { padding: 10px; flex-shrink: 0; display: flex; flex-direction: column; gap: 10px; border-bottom: 1px solid var(--border); }
        .main-btn { width: 100%; padding: 12px; border-radius: 6px; cursor: pointer; transition: 0.2s; display: flex; align-items: center; justify-content: center; gap: 10px; font-weight: 600; font-size: 0.95em; border: none; }
        .btn-new-chat { background: var(--accent); color: white; }
        .btn-new-chat:hover { background: var(--accent-hover); }
        .btn-config { background: #3c3f4e; color: #fff; border: 1px solid #565869; }
        .btn-config:hover { background: #4d5163; }
        
        .chat-list { flex: 1; overflow-y: auto; padding: 10px; min-height: 0; }
        .chat-item { padding: 10px; border-radius: 5px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; color: #c5c5d2; margin-bottom: 5px; font-size: 0.9em; transition: 0.2s; }
        .chat-item:hover { background: #2A2B32; }
        .chat-item.active { background: #343541; color: white; }
        .chat-info { flex: 1; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; display: flex; gap: 8px; align-items: center; }
        .chat-actions { display: none; gap: 5px; }
        .chat-item:hover .chat-actions { display: flex; }
        .action-btn { background: none; border: none; color: #aaa; cursor: pointer; padding: 4px; display: flex; align-items: center; }
        .action-btn:hover { color: white; background: #444; border-radius: 4px; }

        .main-content { flex: 1; display: flex; flex-direction: column; position: relative; }
        .top-header { height: 50px; background: var(--bg-main); border-bottom: 1px solid #0000001a; display: flex; align-items: center; justify-content: space-between; padding: 0 20px; flex-shrink: 0; }
        .robot-status-bar { display: flex; gap: 15px; align-items: center; background: #202123; padding: 5px 15px; border-radius: 20px; font-size: 0.85em; cursor: pointer; border: 1px solid #444; transition: 0.2s; }
        .robot-status-bar:hover { border-color: #888; background: #2A2B32; }
        .stat-item { display: flex; gap: 5px; align-items: center; }
        .chat-container { flex: 1; overflow-y: auto; padding: 20px 0; }
        .message-row { padding: 20px; display: flex; justify-content: center; border-bottom: 1px solid #0000001a; }
        .message-row.ai { background: #444654; }
        .message-content { width: 100%; max-width: 750px; display: flex; gap: 20px; line-height: 1.6; }
        .avatar { min-width: 30px; height: 30px; border-radius: 2px; display: flex; align-items: center; justify-content: center; font-weight: bold; }
        .user-av { background: #5436DA; } .ai-av { background: var(--accent); }

        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 2000; justify-content: center; align-items: center; }
        .modal-content { background: var(--bg-dark); padding: 25px; border-radius: 12px; width: 90%; max-width: 550px; border: 1px solid #555; box-shadow: 0 10px 30px rgba(0,0,0,0.5); max-height: 90vh; overflow-y: auto; }
        h3 { margin-top: 0; color: #fff; border-bottom: 1px solid #444; padding-bottom: 10px; }
        label { color: #ccc; font-size: 0.85em; margin-top: 10px; display: block; margin-bottom: 4px; }
        input[type="text"], input[type="password"], select, textarea { width: 100%; padding: 10px; background: #40414F; border: 1px solid #565869; color: white; border-radius: 5px; box-sizing: border-box; }
        fieldset { border: 1px solid #444; border-radius: 8px; padding: 10px; margin-bottom: 15px; }
        legend { color: var(--accent); font-weight: bold; padding: 0 5px; }
        .range-row { display: flex; align-items: center; gap: 10px; }
        .range-val { width: 40px; text-align: right; font-family: monospace; color: white; font-size: 0.9em; }
        input[type="range"] { flex: 1; }
        .hw-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
        .hw-card { background: #2A2B32; padding: 15px; border-radius: 8px; text-align: center; border: 1px solid #444; }
        .big-val { font-size: 1.8em; font-weight: bold; color: var(--accent); margin: 5px 0; }
        .screen-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }
        .screen-btn { background: #343541; border: 1px solid #565869; color: white; padding: 10px; border-radius: 5px; cursor: pointer; transition: 0.2s; }
        .screen-btn:hover { background: var(--accent); border-color: var(--accent); }
        .btn-primary { width: 100%; padding: 12px; background: var(--accent); border: none; color: white; font-weight: bold; border-radius: 5px; cursor: pointer; margin-top: 20px; }
        .btn-secondary { width: 100%; padding: 10px; background: transparent; border: none; color: #888; cursor: pointer; margin-top: 5px; }
    </style>
</head>
<body>
    <svg style="display:none;">
        <symbol id="icon-plus" viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></symbol>
        <symbol id="icon-settings" viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></symbol>
        <symbol id="icon-trash" viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></symbol>
        <symbol id="icon-share" viewBox="0 0 24 24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></symbol>
    </svg>

    <div class="sidebar">
        <div class="sidebar-header">
            <button class="main-btn btn-new-chat" onclick="createNewChat()">
                <svg class="icon-svg"><use href="#icon-plus"></use></svg> Nuevo Chat
            </button>
            <button class="main-btn btn-config" onclick="openSettings()">
                <svg class="icon-svg"><use href="#icon-settings"></use></svg> Ajustes
            </button>
        </div>
        <div class="chat-list" id="chatList"></div>
    </div>
    
    <div class="main-content">
        <div class="top-header">
            <div style="font-weight:bold; color:#ccc;">Xiaozhi AI</div>
            <div class="robot-status-bar" onclick="openHardware()">
                <div class="stat-item"><span id="headWifiIcon">📶</span> <span id="headWifi">--</span></div>
                <div style="width:1px; height:15px; background:#555;"></div>
                <div class="stat-item"><span id="headBatIcon">🔋</span> <span id="headBat">--%</span></div>
            </div>
        </div>
        <div class="chat-container" id="chatContainer">
            <div style="text-align:center; padding:50px; color:#666;">
                <h2>Bienvenido</h2><p>El robot está listo.</p>
            </div>
        </div>
    </div>

    <div id="settingsModal" class="modal">
        <div class="modal-content">
            <h3><svg class="icon-svg"><use href="#icon-settings"></use></svg> Configuración Avanzada</h3>
            <form id="settingsForm">
                <fieldset>
                    <legend>🤖 Personalidad & Rol</legend>
                    <label>Rol Actual:</label>
                    <select name="current_role" onchange="updatePrompt(this.value)">
                        {% for k,v in presets.items() %}<option value="{{k}}" {% if config.current_role==k %}selected{% endif %}>{{v.label}}</option>{% endfor %}
                    </select>
                    <label>Prompt Sistema:</label>
                    <textarea name="system_prompt" id="sysPrompt" rows="2">{{ config.system_prompt }}</textarea>
                </fieldset>
                <fieldset>
                    <legend>🧠 Inteligencia (IA)</legend>
                    <label>Modelo Groq:</label>
                    <select name="model">{% for m in models %}<option value="{{m}}" {% if config.model==m %}selected{% endif %}>{{m}}</option>{% endfor %}</select>
                    <label>Creatividad (Temp): <span id="tVal" class="range-val">{{config.llm_temperature}}</span></label>
                    <div class="range-row"><small>Preciso</small><input type="range" name="llm_temperature" min="0.1" max="1.5" step="0.1" value="{{ config.llm_temperature }}" oninput="document.getElementById('tVal').innerText=this.value"><small>Loco</small></div>
                    <label>Memoria (Msgs): <span id="mVal" class="range-val">{{config.context_memory}}</span></label>
                    <div class="range-row"><small>0</small><input type="range" name="context_memory" min="0" max="20" step="1" value="{{ config.context_memory }}" oninput="document.getElementById('mVal').innerText=this.value"><small>20</small></div>
                    <label>Respuesta (Tokens): <span id="tkVal" class="range-val">{{config.max_tokens}}</span></label>
                    <div class="range-row"><small>50</small><input type="range" name="max_tokens" min="50" max="4096" step="50" value="{{ config.max_tokens }}" oninput="document.getElementById('tkVal').innerText=this.value"><small>4k</small></div>
                </fieldset>
                <fieldset>
                    <legend>🔊 Voz (TTS)</legend>
                    <select name="voice">{% for k,v in voices.items() %}<option value="{{k}}" {% if config.voice==k %}selected{% endif %}>{{v}}</option>{% endfor %}</select>
                    <label>Velocidad: <span id="rVal" class="range-val">{{config.tts_rate_val}}%</span></label>
                    <div class="range-row"><small>-50%</small><input type="range" name="tts_rate_val" min="-50" max="50" step="5" value="{{ config.tts_rate_val }}" oninput="document.getElementById('rVal').innerText=this.value+'%'"><small>+50%</small></div>
                    <label>Tono: <span id="pVal" class="range-val">{{config.tts_pitch_val}}Hz</span></label>
                    <div class="range-row"><small>-20Hz</small><input type="range" name="tts_pitch_val" min="-20" max="20" step="2" value="{{ config.tts_pitch_val }}" oninput="document.getElementById('pVal').innerText=this.value+'Hz'"><small>+20Hz</small></div>
                </fieldset>
                <fieldset>
                    <legend>🎤 Micrófono</legend>
                    <label>Umbral Silencio: <span id="sVal" class="range-val">{{config.silence_threshold}}</span></label>
                    <div class="range-row"><input type="range" name="silence_threshold" min="200" max="3000" step="100" value="{{ config.silence_threshold }}" oninput="document.getElementById('sVal').innerText=this.value"></div>
                    <label>Ganancia: <span id="gVal" class="range-val">x{{config.mic_gain}}</span></label>
                    <div class="range-row"><input type="range" name="mic_gain" min="0.5" max="5.0" step="0.1" value="{{ config.mic_gain }}" oninput="document.getElementById('gVal').innerText='x'+this.value"></div>
                </fieldset>
                <input type="hidden" name="groq_api_key" value="{{ config.groq_api_key }}">
                <button type="button" class="btn-primary" onclick="saveSettings()">Guardar Todo</button>
                <button type="button" class="btn-secondary" onclick="closeModals()">Cancelar</button>
            </form>
        </div>
    </div>

    <div id="hwModal" class="modal">
        <div class="modal-content">
            <h3><svg class="icon-svg"><use href="#icon-settings"></use></svg> Hardware</h3>
            <div class="hw-grid">
                <div class="hw-card"><div>🔋 Batería</div><div class="big-val" id="batVal">--%</div></div>
                <div class="hw-card"><div>📶 WiFi</div><div class="big-val" id="wifiVal">--</div></div>
            </div>
            <label>🔊 Volumen:</label>
            <input type="range" min="0" max="100" onchange="sendCmd('volume', this.value)">
            <label>📺 Expresión:</label>
            <div class="screen-grid">
                <button class="screen-btn" onclick="sendCmd('screen', 'neutral')">😐 Neutral</button>
                <button class="screen-btn" onclick="sendCmd('screen', 'happy')">😄 Feliz</button>
                <button class="screen-btn" onclick="sendCmd('screen', 'surprise')">😲 Sorpresa</button>
                <button class="screen-btn" onclick="sendCmd('screen', 'listening')">👂 Oído</button>
            </div>
            <button type="button" class="btn-secondary" onclick="closeModals()">Cerrar</button>
        </div>
    </div>

    <script>
        const presets = {{ presets | tojson }};
        let currentChatId = null;

        function updatePrompt(k) { if(presets[k]) document.getElementById('sysPrompt').value = presets[k].prompt; }
        function openSettings() { document.getElementById('settingsModal').style.display = 'flex'; }
        function openHardware() { document.getElementById('hwModal').style.display = 'flex'; fetchRobotStatus(); }
        function closeModals() { document.querySelectorAll('.modal').forEach(m => m.style.display='none'); }

        async function sendCmd(type, val) { await fetch('/api/robot/cmd', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({cmd: type, val: val})}); }
        async function fetchRobotStatus() {
            const res = await fetch('/api/robot/status');
            const data = await res.json();
            document.getElementById('batVal').innerText = data.battery + '%';
            document.getElementById('wifiVal').innerText = data.wifi + 'dBm';
            document.getElementById('headBat').innerText = data.battery + '%';
            document.getElementById('headWifi').innerText = data.wifi + 'dBm';
        }

        async function loadChatList() {
            const res = await fetch('/api/chats');
            const chats = await res.json();
            const list = document.getElementById('chatList');
            list.innerHTML = '';
            chats.forEach(c => {
                const div = document.createElement('div');
                div.className = `chat-item ${c.id === currentChatId ? 'active' : ''}`;
                div.innerHTML = `<div class="chat-info" onclick="loadChat('${c.id}')"><span>💬</span> <span>${c.title}</span></div><div class="chat-actions"><button class="action-btn" onclick="shareChat(event, '${c.id}')"><svg class="icon-svg icon-sm"><use href="#icon-share"></use></svg></button><button class="action-btn" onclick="deleteChat(event, '${c.id}')"><svg class="icon-svg icon-sm"><use href="#icon-trash"></use></svg></button></div>`;
                list.appendChild(div);
            });
        }

        async function createNewChat() { const res = await fetch('/api/new_chat', {method:'POST'}); const d = await res.json(); loadChat(d.id); loadChatList(); }
        async function deleteChat(e, id) { e.stopPropagation(); if(confirm("¿Borrar?")) { await fetch(`/api/delete_chat/${id}`, {method:'POST'}); loadChatList(); } }
        async function shareChat(e, id) { e.stopPropagation(); const res = await fetch(`/api/chat/${id}`); const d = await res.json(); navigator.clipboard.writeText(JSON.stringify(d.messages)); alert("Copiado!"); }

        async function loadChat(id) {
            currentChatId = id; fetch(`/api/set_active/${id}`, {method:'POST'});
            const res = await fetch(`/api/chat/${id}`); const data = await res.json();
            const c = document.getElementById('chatContainer'); c.innerHTML = '';
            data.messages.forEach(m => {
                const row = document.createElement('div');
                row.className = `message-row ${m.role === 'ai' ? 'ai' : ''}`;
                row.innerHTML = `<div class="message-content"><div class="avatar ${m.role==='ai'?'ai-av':'user-av'}">${m.role==='ai'?'AI':'U'}</div><div>${m.content.replace(/\\n/g, '<br>')}</div></div>`;
                c.appendChild(row);
            });
            c.scrollTop = c.scrollHeight; loadChatList();
        }

        async function saveSettings() {
            const fd = new FormData(document.getElementById('settingsForm'));
            await fetch('/save_config', {method:'POST', body:fd});
            closeModals(); alert('Guardado');
        }

        setInterval(() => { if(currentChatId) loadChat(currentChatId); }, 2500);
        setInterval(fetchRobotStatus, 5000);
        loadChatList(); fetchRobotStatus();
    </script>
</body>
</html>
"""

# --- RUTAS API ---
@app.route('/api/robot/cmd', methods=['POST'])
def api_robot_cmd(): d = request.json; send_robot_command(d.get('cmd'), d.get('val')); return jsonify({"status": "sent"})
@app.route('/api/robot/status')
def api_robot_status(): return jsonify(robot_status)
@app.route('/')
def index(): return render_template_string(HTML_TEMPLATE, config=config, models=GROQ_MODELS, voices=VOICE_OPTIONS, presets=PROMPT_PRESETS)
@app.route('/api/chats')
def api_list_chats(): return jsonify(list_all_chats())
@app.route('/api/new_chat', methods=['POST'])
def api_new_chat(): cid = create_new_chat(); global current_active_chat_id; current_active_chat_id = cid; return jsonify({"id": cid})
@app.route('/api/delete_chat/<chat_id>', methods=['POST'])
def api_delete_chat(chat_id): return jsonify({"status": "ok" if delete_chat_file(chat_id) else "error"})
@app.route('/api/chat/<chat_id>')
def api_get_chat(chat_id): c = load_chat_content(chat_id); return jsonify(c if c else {"messages": []})
@app.route('/api/set_active/<chat_id>', methods=['POST'])
def api_set_active(chat_id): global current_active_chat_id; current_active_chat_id = chat_id; return jsonify({"status": "ok"})
@app.route('/save_config', methods=['POST'])
def save_conf_route():
    global config
    config.update({
        "groq_api_key": request.form.get('groq_api_key'), "system_prompt": request.form.get('system_prompt'),
        "current_role": request.form.get('current_role'), "model": request.form.get('model'), "voice": request.form.get('voice'),
        "mic_gain": float(request.form.get('mic_gain')), "llm_temperature": float(request.form.get('llm_temperature')),
        "tts_rate_val": int(request.form.get('tts_rate_val')), "tts_pitch_val": int(request.form.get('tts_pitch_val')),
        "context_memory": int(request.form.get('context_memory')), "silence_threshold": int(request.form.get('silence_threshold')),
        "max_tokens": int(request.form.get('max_tokens'))
    })
    save_config(config); return jsonify({"status": "ok"})

@sock.route('/ws')
def websocket_handler(ws):
    global robot_ws_connection, robot_status
    decoder = opuslib.Decoder(INPUT_RATE, INPUT_CHANNELS) if opuslib else None
    pcm_buffer = b""; is_recording = False; last_speech = 0; start_rec = 0
    try:
        while True:
            data = ws.receive()
            if isinstance(data, str):
                msg = json.loads(data)
                # HANDSHAKE RESTAURADO Y COMPLETO PARA EVITAR CRASH
                if msg.get('type') == 'hello':
                    ws.send(json.dumps({
                        "type": "hello", 
                        "transport": "websocket", 
                        "audio_params": { "rate": 16000, "format": "opus" }
                    }))
                    robot_ws_connection = ws 
                elif msg.get('type') == 'status': robot_status.update(msg)
                elif msg.get('type') == 'listen' and msg.get('state') == 'start':
                    pcm_buffer = b""; is_recording = True; start_rec = time.time(); last_speech = time.time()
                    if decoder: decoder.reset_state()
            elif isinstance(data, bytes) and is_recording:
                # CONFIRMAR ROBOT SI MANDA BYTES
                if robot_ws_connection != ws: robot_ws_connection = ws
                try:
                    chunk = decoder.decode(data, FRAME_SIZE) if decoder else data
                    pcm_buffer += chunk
                    if get_volume(chunk) > config['silence_threshold']: last_speech = time.time()
                    if (time.time() - last_speech) > config['silence_duration'] and (time.time() - start_rec) > 1.0:
                        is_recording = False
                        ws.send(json.dumps({"type": "tts", "state": "stop"}))
                        process_full_interaction(pcm_buffer, ws)
                        pcm_buffer = b""
                except: pass
    except: 
        if robot_ws_connection == ws: robot_ws_connection = None

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, threaded=True)
